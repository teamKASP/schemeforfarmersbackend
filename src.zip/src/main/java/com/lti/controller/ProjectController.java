package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.entity.Bidder;
import com.lti.entity.Bidding;
import com.lti.entity.Crop;
import com.lti.entity.Farmer;
import com.lti.entity.PlaceSellrequest;
import com.lti.entity.Winner;
import com.lti.service.ProjectService;

@RestController
public class ProjectController {

	@Autowired
	ProjectService service;
	
	@RequestMapping(value="/registerfarmer", method = RequestMethod.POST)
	public Farmer addOrUpdateFarmer(@RequestBody Farmer farmer) {
		// TODO Auto-generated method stub
		return service.addOrUpdateFarmer(farmer);
	}
	
	@RequestMapping(value="/registerbidder", method = RequestMethod.POST)
	public Bidder addOrUpdateBidder(@RequestBody Bidder bidder) {
		// TODO Auto-generated method stub
		return service.addOrUpdateBidder(bidder);
	}

	public PlaceSellrequest farmerRequestCropForSale(int farmerId, int cropId) {
		return service.farmerRequestCropForSale(farmerId, cropId);
	}
	
	public void startBidding(int sellRequestId) {
		// TODO Auto-generated method stub
		service.startBidding(sellRequestId);
		
	}

	public Bidding stopBidding(int sellRequestId) {
		// TODO Auto-generated method stub
		return service.stopBidding(sellRequestId);
	}
	
	public void getFarmerSellHistory(int farmerId) {
		service.getFarmerSellHistory(farmerId);
	}
	
	public void placeBid(int bidderId, int sellRequestId,int amount) {
		service.placeBid(bidderId, sellRequestId, amount);
	}
}
